
#' sample new documents, holding the topic distributions fixed
generate_docs <- function (alpha, tw, dd) { 
    if (!requireNamespace("MCMCpack", quietly=TRUE)) {
        stop("Generation requires the MCMCpack package.")
    }

    theta <- MCMCpack::rdirichlet(alpha, length(dd))
    beta_doc <- theta %*% tw
    t(mapply(seq(nrow(beta_doc)), dd, function (b, n) {
        rmultinom(1, beta_doc[b, ], n)
    }))
}

#' resample from each document, holding the topic-mixing proportions
#' fixed
resample_docs <- function (m) {
    result <- Matrix(nrow=n_docs(m), ncol=n_topics(m), sparse=T)
    for (k in 1:n_topics(m)) {
        result <- result +
            rmultinom_sparse(doc_topics(m)[ , k], topic_words(m)[k, ])
    }
    result
}

#' resample everything
generate_topics <- function (a, b, V, K, dd) {
    if (!requireNamespace("MCMCpack", quietly=TRUE)) {
        stop("Generation requires the MCMCpack package.")
    }

    # topics
    beta <- MCMCpack::rdirichlet(rep(b, V), K)
    dtm <- generate_docs(a, beta, dd)
    structure(
        list(
            hyperparameters=list(alpha=a, beta=b),
            topic_words=beta,
            doc_topics=
        ),
        class="mallet_model"
    )
}





