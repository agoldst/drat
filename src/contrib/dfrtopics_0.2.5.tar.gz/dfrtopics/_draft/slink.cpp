
// Single-linkage clustering
// [[Rcpp::export]]
IntegerVector cluster_topics(int nm, int K, NumericVector D) {
    int n = nm * K;
    IntegerVector result(n);
    std::vector<int> ptr(n);
    std::vector<double> level(n);
    std::vector<double> m(n); // distance storage
    int d = 0; // offset into D

    ptr[0] = 0;
    level[0] = std::numeric_limits<double>::infinity();

    for (int i = 1; i < n; ++i) {
        // i starts in its own cluster
        ptr[i] = i;
        // any allowable clustering for i is better than singleton
        level[i] = std::numeric_limits<double>::infinity();

        // initialize distances with point distances
        // D is assumed to store the lower triangle of dist[i, j] by rows
        for (int j = 0; j < i; ++d, ++j) {
            m[j] = D[d];
        }

        for (int j = 0; j < i; ++j) {
            if (level[j] >= m[j]) {
                // i is close enough to cluster j to join it
                // forget m[j] = d[i, j] and remember the (single-link)
                // cluster distance instead
                m[ptr[j]] = std::min(m[ptr[j]], level[j]);
                level[j] = m[j];
                ptr[j] = i;
                Rcout << "join: " << j << " to " << i << std::endl;
            } else {
                // no cluster update, but we still need to guarantee
                // our single-linkage rule by forgetting the point
                // distance and remembering the cluster distance
                m[ptr[j]] = std::min(m[ptr[j]], m[j]);
            }
        }

        for (int j = 0; j < i; ++j) {
            // merge clusters
            if (level[j] >= level[ptr[j]]) {
                ptr[j] = i;
                Rcout << "merge: " << j << " to " << i << std::endl;
            }
        }

    }

    // initialize result, which we'll fill
    // in arbitrary order
    Rcout << "ptr: ";
    for (int i = 0; i < n; ++i) {
        result[i] = -1;
        Rcout << ptr[i] << ",";
    }
    Rcout << std::endl;

    // unwrap the pointer representation,
    // returning only the maximal clusters

    std::sort();

    for (int i = 0, j = 0; i < n; ++i) {
        cur = levels[i];


    for (int i = 0, j = 0; i < n; ++i) {
        if (result[i] != -1)
            continue;

        j = ptr[i]; 
        while (ptr[j] != j) {
            result[j] = i;
            j = ptr[j];
        }
    }

    return unwrap(levels, ptr);
}

IntegerVector unwrap(std::vector<int> ptr, std::vector<double> level) {
    int n = level.size();
    std::vector<int> ids(n), ordering(n), result(n);
    int cur, pi;

    for (int i = 0; i < n; ++i) {
        ordering[i] = i;
        ids[i] = i;
    }

    std::sort(ordering.begin(), ordering.end(), [](a, b) {
        return levels[a] < levels[b];
    });

    for (int i = 0; i < n - 1; ++i) {
        cur = ordering[i];
        pi = ptr[cur];
        // we're only interested in the roots
        result[cur] = result[pi] = std::min(ids[cur], ids[pi]);
        ids[pi] = n + i;
    }

    return result;
}

