library(dfrtopics)
library(dplyr)
library(topicmodels)
library(stm)
library(testthat)
options(java.parameters="-Xmx2g",
        dfrtopics.mallet_logging="none",
        dplyr.show_progress=FALSE)

data_dir <- file.path(path.package("dfrtopics"),
                      "test-data", "pmla-modphil1905-1915")
fs <- list.files(file.path(data_dir, "wordcounts"), full.names=T)[361:420]
stoplist_file <- file.path(path.package("dfrtopics"), "stoplist",
                           "stoplist.txt")
counts <- read_wordcounts(fs) %>%
    wordcounts_remove_rare(200) %>%
    wordcounts_remove_stopwords(readLines(stoplist_file))
K <- 8
V <- n_distinct(counts$word)
meta <- read_dfr_metadata(file.path(data_dir, "citations.tsv"))

trials <- 10
failseeds <- list()
for (seed in c(round(runif(trials, 1, 1e6)), 21665, 346749)) {
    seeds <- seed + 0:2
    ldag <- wordcounts_DocumentTermMatrix(counts) %>%
        LDA(k=K, control=list(alpha=0.1, seed=seeds[1])) %>%
        foreign_model(meta)
    
    corp <- wordcounts_stm_inputs(counts, meta)
    corp$data$journaltitle <- factor(corp$data$journaltitle)
    stg <- stm(corp$documents, corp$vocab, K=K,
               prevalence = ~ journaltitle,
               data=corp$data,
               max.em.its=40, seed=seeds[2],
               verbose=F) %>%
        foreign_model(corp$data)
    
    mm <- wordcounts_instances(counts) %>%
        train_model(n_topics=K, seed = seeds[3])
    
    dst <- model_distances(list(mm, stg, ldag), V)
    cl <- align_topics(dst)
    
    message("seeds. LDA(): ", seeds[1], "; stm(): ", seeds[2],
            "; mallet: ", seeds[3])
    n_cl <- n_distinct(unlist(cl$clusters))
    message("clusters: ", n_cl, appendLF=F)
    if (n_cl < 1.5 * K + .5)
        message(" ok")
    else {
        message(" FAIL")
        failseeds[[length(failseeds) + 1]] <- seeds
    }
}
if (length(failseeds) > 0) {
    message("failseeds:")
    print(failseeds)
}