
    d <- vector("list", n - 1)
    mat <- as.matrix(UScitiesD)
    for (i in 1:(n - 1)) {
        d[[i]] <- vector("list", n - i)
        for (j in (i + 1):n) {
            d[[i]][[j - i]] <- mat[i, j, drop=F]
        }
    }
    dd <- structure(list(d=d), class="model_distances")

