library(stringr)

rand_doi <- function (n) {
    doi <- function () { 
        nn <- sample.int(10, n = sample(10:12, 1)) - 1
        str_c("10.", str_c(nn[1:4], collapse=""),
              "/", str_c(nn[5:10], collapse=""))
    }
    replicate(n, doi())
}

first_names <- c(
    "Vernette",   "Daniella",   "Germaine",   "Joe",        "Marifrances",
    "Lonn",       "Kajol",      "Dorsey",     "Celene",     "Jennilyn",  
    "Naaman",     "Krislynn",   "Beautiful",  "Jamille",    "Rosco",     
    "Willim",     "Bre",        "Shain",      "Percy",      "Oden")
last_names <- c(
    "Josie",    "Krew",     "Monay",    "Velinda",  "Zena",     "Ricky",   
    "Brittini", "Amia",     "Lake",     "Juline",   "Ricardo",  "Joab",    
    "Baudelio", "Theora",   "Memory",   "Champagne", "Simone",   "Kittie",  
    "Ruperto",  "Kathrin")

middles <- c("", str_c(toupper(letters),"."))
suffixes <- c("", ", Jr.", ", Sr.", " III")

rand_auth <- function (n) {
    str_c(str_c(sample(first_names, n, replace=T),
                sample(middles, n, replace=T),
                sample(last_names, n, replace=T),
                sep=" "),
          sample(suffixes, n, replace=T))
}

titles <- c()
journals <- c()
vols <- c()
issues <- c()

rand_meta <- function (n, inner_sep=";;", terminal_sep="\t") {
    nco <- floor(n / 2)
    co_auths <- sample.int(n, n=nco)
    auths <- rand_auth(n)
    auths[co_auths] <- str_c(auths[co_auths], rand_auth(nco), sep=inner_sep)

    ids <- rand_doi(n)
    data.frame(
        id=ids,
        doi=str_c(ids, terminal_sep),
        author=str_c(auths, terminal_sep),
        title=str_c(sample(titles, n=n), terminal_sep),
        journaltitle=str_c(sample(journals, n=n), terminal_sep),
        volume=sample(vols, n=n),
        issue=sample(issues, n=n),
        pubdate=strftime(as.Date(runif(n) * 356 * 150,
                                 origin=as.Date("1850-01-01")),
                         "%Y-%m-%dT00:00:00Z")
        pagerange=,publisher,type,reviewed-work
        


