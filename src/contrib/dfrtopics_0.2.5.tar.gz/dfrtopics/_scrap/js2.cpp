#include <Rcpp.h>
using namespace Rcpp;

// 2015-09-23
//
// Wrote this to test whether moving row_dists to C++ would get any further speed
// gain over just the JS_divergence calculation. Hints via http://gallery.rcpp.org/articles/parallel-distance-matrix/.
// However, there is no significant speed difference, as far as I can tell.

#include <algorithm>


template <typename it1, typename it2>
inline double jsd(it1 itp, it1 pend, it2 itq) {
    
    double total = 0;
    double pq_mean, pi, qi;
    while (itp != pend) {
        pi = *itp++;
        qi = *itq++;
        pq_mean = (pi + qi) / 2;
        if (pi != 0) {
            total += pi * log(pi / pq_mean);
        }
        if (qi != 0) {
            total += qi * log(qi / pq_mean);
        }
    }
    return total / 2;
}

//' Jensen-Shannon divergence between two vectors
//'
//' This function computes the Jensen-Shannon divergence between two vectors,
//' understood as distributions over the index.
//'
//' @param P,Q vectors representing the distributions. Must be of same length.
//'
//' @return \deqn{\sum_j \frac{1}{2}P(j) log\left(\frac{2P(j)}{P(j) +
//' Q(j)}\right) + \frac{1}{2}Q(j) log\left(\frac{2P(j)}{P(j) +
//' Q(j)}\right)}
//'
//' @seealso \code{\link{topic_divergences}}, \code{\link{row_dists}}
//'
//' @export
// [[Rcpp::export]]
NumericMatrix row_jsd(NumericMatrix m) {
    int n = m.nrow();
    NumericMatrix result(n, n);
    
    double g;
    for (int j = 1; j < n; ++j) {
        for (int i = 0; i < j; ++i) {
            NumericMatrix::Row rj = m.row(j);
            NumericMatrix::Row ri = m.row(i);
            g = jsd(ri.begin(), ri.end(), rj.begin());
            result(i, j) = g;
            result(j, i) = g;
        }
    }
    
    return result;
}