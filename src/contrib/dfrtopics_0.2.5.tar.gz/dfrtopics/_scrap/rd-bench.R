rd1 <- function (x, g = JS_divergence) {
    n <- nrow(x)
    result <- matrix(0, nrow = n, ncol = n)
    for (i in seq(n)) {
        for (j in i:n) {
            result[i, j] <- g(x[i, ], x[j, ])
        }
    }
    result[lower.tri(result)] <- t(result)[lower.tri(result)]
    result
}

rd2 <- function (x, g=JS_divergence) {
    # FIXME failure to vectorize. Ugh. Needs Rcpp
    
    n <- nrow(x)
    
    gs <- numeric(choose(n, 2))
    tx <- t(x)  # column-subscripting is a little faster
    
    k <- 0L
    for (j in seq.int(2L, n)) {
        r <- tx[ , j]        # store "row"
        
        for (i in seq.int(1L, j - 1L)) {
            gs[[k + i]] <- g(tx[ , i], r)
        }
        k <- k + j - 1L
    }
    result <- matrix(0, nrow=n, ncol=n)
    result[upper.tri(result)] <- gs
    
    
    # at least take advantage of the symmetry
    result[lower.tri(result)] <- t(result)[lower.tri(result)]
    result
}


