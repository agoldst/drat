options(java.parameters="-Xmx2g",
        dfrtopics.mallet_logging="none")

library(dfrtopics)
suppressPackageStartupMessages(library(dplyr))
library(testthat)
# check for presence of sample data

data_dir <- file.path(path.package("dfrtopics"),
                      "test-data", "pmla-modphil1905-1915")

fs <- list.files(file.path(data_dir, "wordcounts"),
                 full.names=T)[61:120]

stoplist_file <- file.path(path.package("dfrtopics"), "stoplist",
                           "stoplist.txt")
# run a scrap model: we're just doing manipulation here, not worrying
# about quality

n_topics <- 8
insts <- read_wordcounts(fs) %>%
    wordcounts_remove_rare(10000) %>%
    wordcounts_texts() %>%
    make_instances(stoplist_file)

m <- train_model(
    insts,
    n_topics=n_topics,
    n_iters=200,
    threads=1, 
    alpha_sum=5,
    beta=0.01,
    n_hyper_iters=20,
    n_burn_in=20,
    seed=42,
    n_max_iters=10,
    metadata=read_dfr_metadata(file.path(data_dir, "citations.tsv"))
)


out_dir <- tempdir()
if(!file.exists(out_dir)) {
    dir.create(out_dir)
}

state_file <- file.path(out_dir, "state.gz")

if(file.exists(state_file)) {
    unlink(state_file)
}

write_mallet_state(m, state_file)

expect_true(file.exists(state_file),
            info="write_mallet_state() saves a file")

ss_file <- file.path(out_dir, "state_simple.csv")

if(file.exists(ss_file)) {
    unlink(ss_file)
}

simplify_state(state_file, ss_file)
    