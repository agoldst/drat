library(testthat)
library(scuro)

test_check("scuro")
