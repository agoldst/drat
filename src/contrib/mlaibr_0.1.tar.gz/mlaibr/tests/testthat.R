library(testthat)
library(mlaib)

test_check("mlaib")
